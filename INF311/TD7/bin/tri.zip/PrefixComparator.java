
public interface PrefixComparator {
	boolean precede(String v, String w, int d);
}