public class LexicographicComparator implements PrefixComparator {
	
	public boolean precede(String v, String w, int d) {
		// A completer (Exo 6a)
		return false;
	}
}
