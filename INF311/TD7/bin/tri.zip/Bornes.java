class Bornes {
    public int inf, sup;
    
    Bornes(int inf, int sup) {
        this.inf = inf;
        this.sup = sup;
    }
}
	
	
