public class Tri {

	private static final int COUPURE = 5;
	private Dictionnaire dict;
	private PrefixComparator comparator;
	
	Tri (Dictionnaire dict, PrefixComparator comparator){
		this.dict = dict;
		this.comparator = comparator;
	}
		
	public void triInsertion(int lo, int hi, int d) {
		// A completer (Exo 6a)
	}

	public Bornes partition(int v, int lo, int hi, int d) {
		// A completer (Exo 6b)
		return null;
	}

	public void tri(int lo, int hi, int d) {
		// A completer (Exo 6b)
	}

	public void tri() {
		tri(0, dict.size(), 0);
	}

	private int rang(String s, int lo, int hi) {
		// A completer (Exo 6c)
		return 0;
	}
	
	public int rang(String s) {
		return rang(s, 0, dict.size());
	}
}
