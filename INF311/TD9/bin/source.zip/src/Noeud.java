import java.util.Locale;

import tc.TC;

public class Noeud {
	
    public Noeud gauche;
    public Noeud droit;
    public Entree contenu;
    
    public Noeud(Entree e) {
        gauche = null;
        droit = null;
        contenu = e;
    }
    
    public Noeud(Noeud g, Noeud d, Entree e) {
        gauche = g;
        droit = d;
        contenu = e;
    }
    
	// Pour les trois méthodes "comparer" on exploite la surcharge de la 
	// méthode correspondant de la classe "Entree".
    public int comparer(Noeud x) {
        return contenu.comparer(x.contenu);
    }

    public int comparer(Entree e) {
        return contenu.comparer(e);
    }

    public int comparer(String m) {
        return contenu.comparer(m);
    }

    public String toString( ) {
        String str = "";
        if(gauche != null)
            str += "(" + gauche + ")";
        else
            str += "*";
        str += " <- " + contenu + " -> ";
        if(droit != null)
            str += "(" + droit + ")";
        else
            str += "*";
        return str;
    }
        
    // Les méthodes ci-dessus sont données, vous ne devez pas les modifier.
    
    // Exercice 1
    public int hauteur(){
    	throw new Error("classe Noeud : compéter la méthode hauteur");
    }

    // Exercice 2
    public ListeEntiers chercher(String w) {
    	throw new Error("classe Noeud : compléter la méthode chercher");
    }
    
    // Exercice 3
    public boolean estValide(String min, String max) {
    	throw new Error("classe Noeud : compléter la méthode estValide");
    }
    
    // Exercice 4
    public void ajouterOccurrence(String w, int n) {
    	throw new Error("classe Noeud : compléter la méthode ajouterOccurrence");
    }
    
    // Exercice 5
    public void imprimer() {
    	throw new Error("classe Noeud : compléter la méthode imprimer");
    }
    
    // Exercice 6
    public ListeEntrees liste( ) {
    	throw new Error("classe Noeud : compléter la méthode liste");
    }

    // Exercice 7
	public static Noeud indexerTableauTrie(Entree[] entrees, int min, int max) {
		throw new Error("classe Noeud : compléter la méthode indexerTableauTrie");
	}
	
}
