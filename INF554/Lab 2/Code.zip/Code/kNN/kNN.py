from numpy import *
from numpy.linalg import norm

def kNN_prediction(k, X, labels, x):
    '''
    kNN classification of x
    -----------------------
        Input: 
        k: number of nearest neighbors
        X: training data           
        labels: class labels of training data
        x: test instance

        return the label to be associated with x

        Hint: you may use the function 'norm' 
    '''

    # TASK
    
    return 0

 
