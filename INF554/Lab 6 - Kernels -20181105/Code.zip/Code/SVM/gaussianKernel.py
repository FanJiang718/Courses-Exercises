import numpy as np

def gaussianKernel(X1, X2, sigma = 0.1):
    m = X1.shape[0]
    K = np.zeros((m,X2.shape[0]))
    
    # ====================== YOUR CODE HERE =======================
    # Instructions: Calculate the Gaussian kernel (see the assignment
    #				for more details).
    


    
    # =============================================================

    return K
