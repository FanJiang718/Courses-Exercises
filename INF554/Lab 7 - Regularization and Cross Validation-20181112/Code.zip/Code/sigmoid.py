from numpy import *
from math import e
from math import pow

def sigmoid(z):
    # Computes the sigmoid of z.
    g = zeros_like(z)
    # ====================== YOUR CODE HERE ======================
    # Instructions: Implement the sigmoid function as given in the
    # assignment (and use it to *replace* the line above).
    
    
    
    
    # =============================================================
    return g

