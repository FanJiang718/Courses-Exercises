from numpy import *
from sigmoid import sigmoid

def computeGradreg(theta, X, y, l):
    # Computes the gradient of the cost with respect to the parameters.

    m = X.shape[0] # number of training examples
    
    grad = zeros_like(theta) #initialize gradient

    # ====================== YOUR CODE HERE ======================
    # Instructions: Compute the gradient of cost for each theta,
    # as described in the assignment.
    
    
    
    
    
    
    
    
    # =============================================================
	
    return grad
    
