from numpy import *
from sigmoid import sigmoid

def computeCostreg(theta, X, y, l):
    # Computes the cost of using theta as the parameter for regularized logistic regression.
    
    m = X.shape[0] # number of training examples
    J = 0

    # ====================== YOUR CODE HERE ======================
    # Instructions: Calculate the error J of the decision boundary
    #               that is described by theta  (see the assignment 
    #				for more details).
    
    
    

    
    
    
    # =============================================================
    
    return J



