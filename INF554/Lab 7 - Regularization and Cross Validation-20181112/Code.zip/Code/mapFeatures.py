import numpy as np

def mapFeatures(X, degree=6):
    '''
    Generate a new feature matrix consisting of all polynomial combinations of 
    the features with degree less than or equal to the specified degree. 
    '''

    # TODO
    F = X
    

    return F 
