from numpy import *
from scipy.cluster.vq import kmeans2

def spectralClustering(W, k):

    # ====================== ADD YOUR CODE HERE ======================
    # Instructions: Perform spectral clustering to partition the 
    #               data into k clusters. Implement the steps that
    #               are described in Algorithm 2 on the assignment.    
    
	
	
	
	
    
    
    
    # =============================================================

	return labels
